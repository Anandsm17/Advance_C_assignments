/*
Name : Anand S M
Date : 15-12-2023
Description : Program to generate the prime series upto the given limit using functions
Sample Execution:

Test case 1: 
user@emertxe]./prime_or_not
Enter a number: 2
2

Test case 2: 
user@emertxe]./prime_or_not
Enter a number: 4
2 3

Test case 3: 
user@emertxe]./prime_or_not
Enter a number: 20
2 3 5 7 11 13 17 19

Test case 5: 
user@emertxe]./prime_or_not
Enter a number: -2
Invalid input

Test case 6: 
user@emertxe]./prime_or_not
Enter a number: 1
Invalid input
*/




//code

#include <stdio.h>                                                              //Header files
#include <math.h>

int is_prime(int);                                                              //Function declarations
void generate_prime(int);

int main()
{
    int limit;
    
    //printf("Enter the limit: ");
    scanf("%d", &limit);
    
    if (limit > 1)                                                              //Function call to check and generate the prime series
    {
        generate_prime(limit);
    }
    else
    {
        printf("Invalid input\n");
    }
    
    return 0;
}

void generate_prime(int limit)                                                  //Function definition for generating the prime series
{
    int ret;
    for(int i=2 ; i <= limit; i++)                                              //Loop to call the is_prime function and printing the series
    {
        ret = is_prime(i);
        if(ret == 1)
            printf("%d ",i);
    }
}

int is_prime(int num)                                                           //Function definition to check the number is prime number or not
{
    int flag=0;
    for(int i=2 ; i<=sqrt(num);i++ )
    {
        if(num % i == 0)                                                        //Checking the num is prime or not using loops
        {
            flag=1;
            break;
        }
    }
    if(flag == 0)                                                               //Returning the flag value
        return 1;
    else
        return 0;
}