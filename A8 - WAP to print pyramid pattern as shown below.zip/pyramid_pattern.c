/*
Name : Anand S M
Date : 31-10-2023
Description : Program to print pyramid pattern as given below
Sample Output:
Test Case 1:
Enter the number: 4
4
3 4
2 3 4
1 2 3 4
2 3 4
3 4
4
Test Case 2:
Enter the number: 5
5
4 5
3 4 5
2 3 4 5
1 2 3 4 5
2 3 4 5
3 4 5
4 5
5
*/

//code

#include<stdio.h>

int main()
{
    int row,col,num;                                                            //Variable declarations
   
    printf("enter the number:");                                                //Read num 
    scanf("%d",&num);    

    for (row=num ; row>=1 ; row--)                                                    //Prints the upper half pattern based on input 
    {
        for(col=row ; col<=num ; col++)
        {   
            printf("%d ",col);
        }
        printf("\n");
    } 
                                                                                //Prints the lower half pattern based on input 
    for(row=2 ; row<=num ; row++)
    {
        for(col=row ; col<=num ; col++)
        {                    
            printf("%d ",col);
        }
        printf("\n");
    }
    
return 0;
}