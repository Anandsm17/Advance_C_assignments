#include <stdio.h>
#include <stdlib.h>

// Function to display the element stored at the memory location pointed by ptr
void displayElement(void *ptr, int type) {
    // Based on the type, interpret the data correctly and display
    switch (type) {
        case 1: // If type is int
            printf("%d -> %d (int)\n", *((int *)ptr + 1), *((int *)ptr));
            break;
        case 2: // If type is char
            printf("%d -> %c (char)\n", *((char *)ptr + 1), *((char *)ptr));
            break;
        case 3: // If type is float
            printf("%d -> %f (float)\n", *((int *)ptr + 1), *((float *)ptr));
            break;
        case 4: // If type is double
            printf("%d -> %lf (double)\n", *((int *)ptr + 1), *((double *)ptr));
            break;
        default:
            printf("Invalid type\n");
    }
}

int main() {
    int choice, type;
    void *ptr = malloc(8); // Allocate 8 consecutive bytes in memory

    printf("Menu:\n");
    printf("1. Add element\n2. Remove element\n3. Display element\n4. Exit from the program\n");

    while (1) {
        printf("Choice ---> ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: // Add element
                printf("Enter the type you have to insert:\n");
                printf("1. int\n2. char\n3. float\n4. double\nChoice ---> ");
                scanf("%d", &type);

                switch (type) {
                    case 1: // Add int
                        printf("Enter the int: ");
                        scanf("%d", (int *)ptr);
                        break;
                    case 2: // Add char
                        printf("Enter the char: ");
                        scanf(" %c", (char *)ptr);
                        break;
                    case 3: // Add float
                        printf("Enter the float: ");
                        scanf("%f", (float *)ptr);
                        break;
                    case 4: // Add double
                        printf("Enter the double: ");
                        scanf("%lf", (double *)ptr);
                        break;
                    default:
                        printf("Invalid type\n");
                }
                break;
            case 2: // Remove element
                printf("Enter the index value to be deleted: ");
                int index;
                scanf("%d", &index);
                if (index == 0) {
                    printf("Cannot delete index 0\n");
                } else {
                    *((int *)ptr + index) = 0; // Mark index as deleted
                    printf("Index %d successfully deleted.\n", index);
                }
                break;
            case 3: // Display element
                printf("------------------------\n");
                for (int i = 0; i < 8 / sizeof(int); i++) {
                    if (*((int *)ptr + i) != 0) {
                        printf("%d -> ", i);
                        displayElement((int *)ptr + i, type);
                    }
                }
                printf("------------------------\n");
                break;
            case 4: // Exit
                free(ptr); // Free allocated memory
                printf("Exiting program...\n");
                exit(0);
            default:
                printf("Invalid choice\n");
        }
    }

    return 0;
}
