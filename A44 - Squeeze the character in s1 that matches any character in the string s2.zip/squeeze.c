/*
Name : Anand S M
Date of suubmission : 16-05-2024
Descrption : Program to Squeeze the character in s1 that matches any character in the string s2
Sample execution: -
Test Case 1:
user@emertxe] ./squeeze
Enter s1 : Dennis Ritchie
Enter s2 : Linux
After squeeze s1 : Des Rtche


Test Case 2:
user@emertxe] ./squeeze
Enter s1 : Welcome
Enter s2 : Emertxe
After squeeze s1 : Wlco

*/

//code

#include <stdio.h>
#include <string.h>

void squeeze(char *s1, const char *s2) {
    char *src = s1;  // Pointer to traverse s1
    char *dest = s1; // Pointer to track modified s1

    while (*src) {
        char *check = (char *)s2; // Pointer to traverse s2
        int match = 0; // Flag to indicate a match

        // Check if the character in s1 matches any character in s2
        while (*check) {
            if (*src == *check) {
                match = 1;
                break;
            }
            check++;
        }

        // If no match is found, copy the character to the modified s1
        if (!match) {
            *dest = *src;
            dest++;
        }
        src++;
    }
    *dest = '\0'; // Null-terminate the modified s1
}

int main() {
    char s1[100], s2[100];

    printf("Enter s1: ");
    fgets(s1, sizeof(s1), stdin);

    printf("Enter s2: ");
    fgets(s2, sizeof(s2), stdin);

    // Remove newline characters from input strings
    s1[strcspn(s1, "\n")] = '\0';
    s2[strcspn(s2, "\n")] = '\0';

    squeeze(s1, s2);

    printf("After squeeze s1: %s\n", s1);

    return 0;
}
