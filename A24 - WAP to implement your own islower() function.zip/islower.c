/*
Name : Anand S M
Date : 22-11-2023
Description : Program to implement own islower() function
Sample execution :-)

Test Case 1:

Enter the character: a
Entered character is lower case alphabet

Test Case 2:
Enter the character:3
Entered character is not lower case alphabet
*/

//code

#include <stdio.h>

int my_islower(char);                                                           //Function declaration

int main()
{
    char ch;                                                                    // Variable declaration
    int ret;
    
    //printf("Enter the character:");
    scanf("%c", &ch);                                                           //Read a character ch
    
    ret = my_islower(ch);                                                       // Function call
    
    ret == 0 ? printf("Entered character is not lower case alphabet") :                                                             // Printing the result based on ret
               printf("Entered character is lower case alphabet");
}

int my_islower(char ch)                                                         // Function definition for islower() function implementation
{
    if ( (ch >= 97 && ch <= 122) )                                              // Comparing ch with Ascii values for lowecase alphabets and return 1 or 0 based on the result 
        return 1;
    else
        return 0;
}