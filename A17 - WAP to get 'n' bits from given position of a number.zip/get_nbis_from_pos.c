/*
Name : Anand S M
Date : 11-11-2023
Description : Program to get 'n' bits from given position of a number
Sample Execution :-) 

Test Case 1:

Enter the number: 12

Enter number of bits: 3

Enter the pos: 4

Result = 3

Test Case 2:

Enter the number: 15

Enter number of bits: 2

Enter the pos: 2

Result =  3
*/

//code

#include <stdio.h>

int get_nbits_from_pos(int, int, int);                                          //Function declaration

int main()
{
    int num, n, val, res = 0;                                                   //Variable declararion
    
    printf("Enter num, n and val:");
    scanf("%d%d%d", &num, &n, &val);                                            //Read num,n and val
    
    res = get_nbits_from_pos(num, n, val);                                      //Function call by passing the parameters
    
    printf("Result = %d\n", res);                                               //Displaying the result
}

int get_nbits_from_pos(int num,int n,int val)
{                                                                               // Getting n bits and change the pos value to obtain res
    int res;
    res=(((1 << val) - 1) & (num >> (val - n + 1)));
    return res;                                                                 //Returning the result to function call
}