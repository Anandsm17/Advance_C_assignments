/*
Name : Anand S M
Date : 27-10-2023
Description : Program to generate positive Fibonacci numbers

Sample execution :-)

Test Case 1 :

user@emertxe] ./fibbonacci_series

Enter a number: 8

0 1 1 2 3 5 8

Test Case 2:

Enter a number: 10

0 1 1 2 3 5 8

Test Case 3:

Enter a number: 21

0 1 1 2 3 5 8 13 21

Test Case 4:

Enter a number: -21

Invalid input
*/
#include<stdio.h>

int main()
{
    int num,i;
    int first=0,second=1;                                                       //Declaration of first and second terms
    int sum=0;
    printf("Enter a number: ");
    scanf("%d",&num);
    if(num>0)
    {
        printf("%d %d ",first,second);                                          //Printing 0 and 1
        while(sum < num)                                                         //Checking the sum is less than num
        {
            sum=first+second;                                                   //Finding the next number(sum) using first and second
            printf("%d ",sum);                                                  //Printing the sum
            first=second;                                                       //Assigning the second value to first
            second=sum;                                                         //Assigning the sum value to second  to find the sum again by loop
        }
    }
    else if(num == 0)
        printf("0");
    else
        printf("Invalid input");
    return 0;
}