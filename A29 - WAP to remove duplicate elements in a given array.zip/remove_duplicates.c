/*
Name : Anand S M
Date of submission : 07-05-2024
Description : Program to remove duplicate elements in a given array

Input:
Read size and elements into the array

Output:
Test Case 1:

Enter the size: 5

Enter elements into the array: 5 1 3 1 5

After removing duplicates: 5 1 3

Test Case 2:

Enter the size: 5

Enter elements into the array: 2 1 1 1 5

After removing duplicates: 2 1 5
*/

//code

#include <stdio.h>

// Function prototype for removing duplicates
void fun(int arr1[], int size, int arr2[], int *new_size);

int main() {
    int size;
    printf("Enter the size: ");
    scanf("%d", &size);

    int arr1[size]; // Original array with duplicates
    printf("Enter elements into the array: ");
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr1[i]);
    }

    int arr2[size]; // Array to store non-duplicate elements
    int new_size;   // Size of the new array after removing duplicates
    fun(arr1, size, arr2, &new_size); // Remove duplicates

    printf("After removing duplicates: ");
    for (int i = 0; i < new_size; i++) {
        printf("%d ", arr2[i]); // Print non-duplicate elements
    }
    printf("\n");

    return 0;
}

// Function to remove duplicates and store non-duplicate elements in arr2
void fun(int arr1[], int size, int arr2[], int *new_size) {
    int index = 0; // Index for arr2
    for (int i = 0; i < size; i++) {
        int duplicate = 0; // Flag for duplicates
        for (int j = 0; j < index; j++) {
            if (arr1[i] == arr2[j]) {
                duplicate = 1; // Element is a duplicate
                break;
            }
        }
        if (!duplicate) {
            arr2[index++] = arr1[i]; // Store non-duplicate
        }
    }
    *new_size = index; // Update new_size
}
