/*
Name : Anand S M
Date of submission : 02-05-2024
Description : Program to print the values in sorted order without modifying or copying array
Sample execution: -
Test Case 1:
user@emertxe] ./sort
Enter the size : 5
Enter 5 elements 
10 1 3  8 -1
After sorting: -1 1 3 8 10
Original array values 10 1 3 8 -1

Test Case 2:
user@emertxe] ./sort
Enter the size : 7
Enter 7 elements 
1 3 2 5 4 7 6
After sorting: 1 2 3 4 5 6 7
Original array values 1 3 2 5 4 7 6

Test Case 3:
user@emertxe] ./sort
Enter the size : 4
Enter 4 elements 
-1 -2  4 3
After sorting: -2 -1 3 4
Original array values -1 -2  4 3
*/

//code

#include <stdio.h>

// Function to print the values in sorted order
void print_sort(int arr[], int size) {
    int temp;

    // Create a new array to store the original values
    int original[size];

    // Copy the elements of the original array into the new array
    for (int i = 0; i < size; i++) {
        original[i] = arr[i];
    }

    // Print "After sorting" label
    printf("After sorting: ");

    // Sort the array using a bubble sort algorithm
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                // Swap the elements if they are in the wrong order
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    // Print the sorted array
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    // Print the original array values using the new array
    printf("Original array values: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", original[i]);
    }
    printf("\n");
}

int main() {
    int size;

    // Read the size of the array from the user
 //   printf("Enter the size of the array: ");
    scanf("%d", &size);

    int arr[size];

    // Read the elements of the array from the user
   // printf("Enter %d elements:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }

    // Call the function to sort and print the values in sorted order
    print_sort(arr, size);

    return 0;
}
