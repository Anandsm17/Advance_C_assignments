/*
Name : Anand S M
Date : 31-10-2023
Description : Program to check whether a given number is prime or not.
Sample Execution :-)

Test case 1: 
user@emertxe]./prime_or_not
Enter a number: 2
2 is a prime number

Test case 2: 
user@emertxe]./prime_or_not
Enter a number: 4
4 is not a prime number

Test case 3: 
user@emertxe]./prime_or_not
Enter a number: 101
101 is a prime number

Test case 4: 
user@emertxe]./prime_or_not
Enter a number: 47
47 is a prime number

Test case 5: 
user@emertxe]./prime_or_not
Enter a number: -2
Invalid input

Test case 6: 
user@emertxe]./prime_or_not
Enter a number: 25
25 is not a prime number

Test case 7: 
user@emertxe]./prime_or_not
Enter a number: 2089
2089 is a prime number
*/
//code

#include <stdio.h>

int main()
{
    int i,num,count=0;                                                          //Variable declaration
    //printf("Enter a number: ");
    scanf("%d",&num); 
                                                                                 //Read num
    if(num > 1 )                                                                // Cheking for +ve digits only
    {
        for (i=2;i*i<=num;i++)                                                  // Checking the factors and breaking the loops using break
        {
            if(num % i == 0)
            {
                count++;                                                                    
                break;
            }
        }
        
        count == 0 ? printf("%d is a prime number",num) : printf("%d is not a prime number",num);   //Printing the result based on count value
    }
    else
        printf("Invalid input");                                                //Message for input less than 1 or -ve number
    
    return 0;
}