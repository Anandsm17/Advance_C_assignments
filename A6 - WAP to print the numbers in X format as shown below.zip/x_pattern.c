/*
Name : Anand S M
Date : 27-10-2023
Description : Program to print the numbers in X format
Sample execution :-)
Test Case 1:

Enter the number: 4
1  4
 23
 23
1  4

Test Case 2:
Enter the number: 5
1   5
 2 4
  3
 2 4
1   5
*/
#include<stdio.h>

int main()
{
    int n,row,col;                                                              //Declaration of inpput n ,row and column variable
    printf("Enter the number : ");
    scanf("%d",&n);
    for(row=0;row<n;row++)                                                      //Row loop upto n value
    {
        for(col=0;col<n;col++)                                                  //column loop upto n value
        {
            if( (row == col) || (n == row+col+1 ))                              //Displaying the col+1 value if the condition is true
                printf("%d",col+1);
            else                                                                //else space will be printed            
                printf(" ");
        }
        printf("\n");
    }
    return 0;
}