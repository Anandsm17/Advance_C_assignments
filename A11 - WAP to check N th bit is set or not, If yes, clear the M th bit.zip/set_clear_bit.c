/*
Name : Anand S M
Date :30-10-2023
Description : Program to check Nth bit is set or not, If yes, Clear the Mth bit
Sample Execution:

Test Case 1:

Enter the number: 19

Enter 'N': 1

Enter 'M': 4

Updated value of num is 3 

Test Case 2:

Enter the number: 19

Enter 'N': 2

Enter 'M': 4

Updated value of num is 19 
*/

//code

#include <stdio.h>

int main()
{
    int num,N,M;                                                                //Declaration and taking the input num,N and M
    printf("Enter the number: ");
    scanf("%d",&num);
    printf("Enter 'N': ");
    scanf("%d",&N);
    printf("Enter 'M': ");
    scanf("%d",&M);
    
    if ( (num & (1 << N)) != 0)                                                 //Checking the Nth bit is set or not
    {
        num = num & (~(1 << M));                                                //If the Nth bit is set then changing the Mth bit
        printf("Updated value of num is %d",num);
    }
    else
        printf("Updated value of num is %d",num);                               //Displaying num if Nth bit is not set
    return 0;
}