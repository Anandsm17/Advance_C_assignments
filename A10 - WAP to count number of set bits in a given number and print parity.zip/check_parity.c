/*
Name : Anand S M
Date :29-10-2023
Description : Program to count number ofset bits in a given number and print parity
Sample Execution:
Test Case 1:

Enter the number : 7

Number of set bits = 3

Bit parity is Odd

Test Case 2:

Enter the number : 15

Number of set bits = 4

Bit parity is Even

Test Case 3:

Enter the number : 6

Number of set bits = 2

Bit parity is Even
*/

//code
#include <stdio.h>

int main()
{
    int num,count=0;                                                              //Declaration of num and count
    printf("Enter the number : ");
    scanf("%d",&num);                                                           //Taking num as input
    printf("\n");
    
    for(int i=0; i < (sizeof(num)*8) ; i++)                                     //Checking every bit of num using loop and using sizeof() to find the number of bits
    {
        if ( (num & (1 << i)) != 0 )                                            //Checking for set bits and incrementing the count
        count++;
    }
    printf("Number of set bits = %d\n",count);                                  //Displaying the number of set bits
    printf("\n");
    
    if ((count & 1) != 0)                                                         //Checking for parity bit
        printf("Bit parity is Odd");
    else
        printf("Bit parity is Even");

    return 0;
}