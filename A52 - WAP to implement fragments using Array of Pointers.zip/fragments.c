/*
Name : Anand S M
Date of submission : 16-05-2024
Description : Program to implement fragments using Array of Pointers
Sample Execution:
Test case 1:
user@emertxe] ./fragmentsEnter
Enter no.of rows : 3
Enter no of columns in row[0] : 4
Enter no of columns in row[1] : 3
Enter no of columns in row[2] : 5
Enter 4 values for row[0] : 1 2 3 4
Enter 3 values for row[1] : 2 5 9
Enter 5 values for row[2] : 1 3 2 4 1

Before sorting output is:

1.000000 2.000000 3.000000 4.000000 2.500000

2.000000 5.000000 9.000000 5.333333

1.000000 3.000000 2.000000 4.000000 1.000000 2.200000

After sorting output is:

1.000000 3.000000 2.000000 4.000000 1.000000 2.200000

1.000000 2.000000 3.000000 4.000000 2.500000

2.000000 5.000000 9.000000 5.333333
*/

//code

#include <stdio.h>
#include <stdlib.h>

void calculateAverage(int rows, int *arr[]) {
    for (int i = 0; i < rows; i++) {
        int sum = 0;
        for (int j = 0; j < arr[i][0]; j++) {
            sum += arr[i][j + 1];
        }
        float average = (float)sum / arr[i][0];
        arr[i][arr[i][0] + 1] = average; // Store average in the extra memory block
    }
}

int compare(const void *a, const void *b) {
    float avg1 = *((float *)a + 1); // Extract average from the extra memory block
    float avg2 = *((float *)b + 1);
    if (avg1 < avg2) return -1;
    if (avg1 > avg2) return 1;
    return 0;
}

void sortArray(int rows, int *arr[]) {
    qsort(arr, rows, sizeof(int *), compare);
}

void printArray(int rows, int *arr[]) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < arr[i][0]; j++) {
            printf("%.6f ", (float)arr[i][j + 1]);
        }
        printf("\n");
    }
}

int main() {
    int rows;
    printf("Enter no. of rows: ");
    scanf("%d", &rows);

    int *arr[rows];

    for (int i = 0; i < rows; i++) {
        int cols;
        printf("Enter no. of columns in row[%d]: ", i);
        scanf("%d", &cols);

        arr[i] = (int *)malloc((cols + 2) * sizeof(int)); // +2 for values and average

        arr[i][0] = cols; // Store number of columns in the first element

        printf("Enter %d values for row[%d]: ", cols, i);
        for (int j = 0; j < cols; j++) {
            scanf("%d", &arr[i][j + 1]);
        }
    }

    calculateAverage(rows, arr);
    printf("\nBefore sorting output is:\n");
    printArray(rows, arr);

    sortArray(rows, arr);
    printf("\nAfter sorting output is:\n");
    printArray(rows, arr);

    for (int i = 0; i < rows; i++) {
        free(arr[i]);
    }

    return 0;
}

