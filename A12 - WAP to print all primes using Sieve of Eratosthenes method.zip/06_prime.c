/*
Name : Anand S M
Date : 31-10-2023
Description : Program to print all primes using Sieve of Eratosthenes method
Sample execution :-)

Test Case 1: A positive number
user@emertxe] ./prime_series
Enter the value of 'n' : 20
The primes less than or equal to 20 are : 2, 3, 5, 7, 11, 13, 17, 19
Test Case 2 :

Enter the value of 'n' : -20
Please enter a positive number which is > 1
*/

//code

#include<stdio.h>

int main()
{
 
    int n,i;                                                                    // Declaration of variables    
    printf("Enter the value of 'n': ");                                         // Read num
    scanf("%d",&n);                                                             

    if(n > 1)                                                                 // Checking number is +ve or -ve 
    { 
        int array[n+1];                                                         // Declaration int array
 
        for(int i = 1 ; i <= n ; i++)                                           // Using for loop to initalise the array
        {
            if(array[n+1]) 
                array[i]=i;                                                     // prime array stored in index i=1,2,3,4....  
        }
      
        for(int i = 2; i*i <= n; i++)                                           // Muliplication  less than equal to num and i value  increement                           
        {
            if(array[i] != -1);                                                 // Checking if array is not equal to -1 then print the value
            {
                for(int j = 2*i ; j <= n ; j += i )                             // i=2 to run another loop  to get j value  addition to i value j+=i 
                {
                    array[j] = -1;                                              //Assume  array j index value -1    
                }
            }
        }
        printf("The primes less than or equal to %d are: ",n);                  // to print the prime contents
        for (int i = 2; i<= n; i++)
        {
            if(array[i] != -1)                                                  // array index not equal to j=-1 value
            {        
                printf("%d, ",i);                                               // Printing the prime numbers  
            }
        }
    } 
 else
   {
    printf("Please enter a positive number which is > 1\n");                     // Error message for negative number as input
   }
 return 0;
}