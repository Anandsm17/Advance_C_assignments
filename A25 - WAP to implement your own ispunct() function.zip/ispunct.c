/*
Name : Anand S M
Date of submission : 07-05-2024
Description : Program to to implement your own ispunct() function
Inputs: -

        An ASCII character

Outputs: -

        0 or non-zero value based on condition success or failure

Sample execution: -
Test Case 1:
user@emertxe] ./c_type_lib
Enter the character: a
Entered character is not punctuation character
Test Case 2:
Enter the character:$
Entered character is punctuation character

*/


//code

#include <stdio.h>

// Function prototype for custom ispunct() function
int my_ispunct(int ch);

int main() {
    char ch;
    int ret;

    printf("Enter the character: ");
    scanf("%c", &ch);

    ret = my_ispunct(ch); // Call custom ispunct() function

    if (ret) {
        printf("Entered character is punctuation character\n");
    } else {
        printf("Entered character is not punctuation character\n");
    }

    return 0;
}

// Custom ispunct() function to check if a character is a punctuation character
int my_ispunct(int ch) {
    // ASCII range for punctuation characters
    if ((ch >= 33 && ch <= 47) || (ch >= 58 && ch <= 64) || 
        (ch >= 91 && ch <= 96) || (ch >= 123 && ch <= 126)) {
        return 1; // Return 1 if ch is a punctuation character
    } else {
        return 0; // Return 0 if ch is not a punctuation character
    }
}
