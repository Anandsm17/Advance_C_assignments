/*
Name : Anand S M
Date of submission : 02-05-2024
Description : Program to find factorial of given number using recursion

Sample execution: -
Test Case 1:
user@emertxe] ./factorial
Enter the value of N : 7
Factorial of the given number is 5040

Test Case 2:
Enter the value of N : 5
Factorial of the given number is 120

Test case 3:
Enter the value of N : -1
Invalid Input

Test case 4:
Enter the value of N : 0
Factorial of the given number is 1

*/

//code

#include <stdio.h>

// Function to calculate factorial using recursion
unsigned long long int factorial(int n) {
    // Base case: factorial of 0 or 1 is 1
    if (n == 0 || n == 1) {
        return 1;
    } else {
        // Recursive case: multiply n with factorial of (n-1)
        return n * factorial(n - 1);
    }
}

int main() {
    int num;

    // Read input number from user
    printf("Enter the value of N: ");
    scanf("%d", &num);

    // Check if input number is negative
    if (num < 0) {
        printf("Invalid Input\n");
    } else {
        // Calculate factorial and store in 'fact'
        unsigned long long int fact = factorial(num);

        // Print the factorial result
        printf("Factorial of the given number is %llu\n", fact);
    }

    return 0;
}
