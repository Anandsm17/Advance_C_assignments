/*
Name : Anand S M
Date : 10-11-2023
Description : Program to get 'n' bits of a given number
Sample execution :-)

Test Case 1:

Enter the number: 10

Enter number of bits: 3

Result = 2

Test Case 2:

Enter the number: 15

Enter number of bits: 2

Result = 3

*/

//code

#include <stdio.h>

int get_nbits(int, int);

int main()
{
    int num, n, res = 0;
    
    printf("Enter num and n:");
    scanf("%d%d", &num, &n);
    
    res = get_nbits(num, n);
    
    printf("Result = %d\n", res);
}

int get_nbits(int num,int n)                                                    //Function definition
{
    int result = 0;
    result = ((1<<n)-1) & num;                                                  //Using mask to get the nth bit and returning the res value to main()
    return result;
}