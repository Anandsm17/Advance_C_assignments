/*
Name : Anand S M
Date : 12-11-2023
Description : Program to toggle 'n' bits from given position of a number
Sample Execution :-) 

Test Case 1:

Enter the number: 10

Enter number of bits: 3

Enter the pos: 5

Result = 50

Test Case 2:

Enter the number: 15

Enter number of bits: 2

Enter the pos: 2

Result =  9
*/

//code

#include <stdio.h>

int toggle_nbits_from_pos(int, int, int);

int main()
{
    int num, n, pos, res = 0;                                                   // Variable declaration
    
    printf("Enter num, n and val:");
    scanf("%d%d%d", &num, &n, &pos);                                            // Read inputs
    
    res = toggle_nbits_from_pos(num, n, pos);                                   // Calling the function
    
    printf("Result = %d\n", res);
}

int toggle_nbits_from_pos(int num,int n, int pos)
{
    num = num ^ ~(~0 << n) << (pos -n+1);                                       // Toggling the bit and returning the num        
    return num;
}