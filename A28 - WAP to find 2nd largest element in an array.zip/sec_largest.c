/*
Name : Anand S M
Date of submission : 02-05-2024
Description : Program to find 2nd largest element in an array
Sample Execution:

Test Case 1:
Enter the size of the Array : 5
Enter the elements into the array: 5 1 4 2 8
Second largest element of the array is 5
Test Case 2:
Enter the size of the Array : 4
Enter the elements into the array: 66 22 11 3
Second largest element of the array is 22

*/


//code

#include <stdio.h>

int sec_largest(int [], int);   //Function declaration

int main() 
{
    int size, ret;          // Variable declaration

    // Read size from the user
    printf("Enter the size of the array: ");
    scanf("%d", &size);

    int arr[size]; // Declare an array of given size

    // Read elements into the array
    printf("Enter the elements into the array: ");
    for (int i = 0; i < size; i++) 
    {
        scanf("%d", &arr[i]);
    }

    // Function call to find the second largest element
    ret = sec_largest(arr, size);

    // Print the second largest element
    printf("Second largest element of the array is %d\n", ret);

    return 0;
}

// Function definition to find the second largest element in the array
int sec_largest(int arr[], int size)
{
    int largest = arr[0]; // Initialize largest to the first element
    int sec_largest = arr[1]; // Initialize second largest to the second element

    // Make sure largest and sec_largest are correctly set initially
    if (largest < sec_largest) 
    {
        int temp = largest;
        largest = sec_largest;
        sec_largest = temp;
    }

    // Iterate through the array to find the largest and second largest elements
    for (int i = 2; i < size; i++) 
    {
        if (arr[i] > largest)
        {
            sec_largest = largest;
            largest = arr[i];
        } else if (arr[i] > sec_largest && arr[i] != largest)
        {
            sec_largest = arr[i];
        }
    }

    return sec_largest;
}
