/*
Name : Anand S M
Date : 15-12-2023
Description : Program to check whether a given number is prime or not using function

Sample execution :-)

Test case 1: 
user@emertxe]./prime_or_not
Enter a number: 2
2 is a prime number

Test case 2: 
user@emertxe]./prime_or_not
Enter a number: 4
4 is not a prime number

Test case 3: 
user@emertxe]./prime_or_not
Enter a number: 101
101 is a prime number

Test case 4: 
user@emertxe]./prime_or_not
Enter a number: 47
47 is a prime number

Test case 5: 
user@emertxe]./prime_or_not
Enter a number: -2
Invalid input

Test case 6: 
user@emertxe]./prime_or_not
Enter a number: 25
25 is not a prime number

Test case 7: 
user@emertxe]./prime_or_not
Enter a number: 2089
2089 is a prime number


*/

//code



#include <stdio.h>

int is_prime(int);                                                              //Function declaration

int main()
{
    int num;                                                                    //Variable declarations
    //printf("Enter a number: ");
    scanf("%d",&num);
    if(num > 0)                                                                 //Checking for positive numbers
    {
    if(is_prime(num) == 0)                                                      //Function call
        printf("%d is a prime number", num);
    else
        printf("%d is not a prime number", num);
    }
    else
        printf("Invalid input");

    return 0;
}

int is_prime(int number)                                                        //Function definition
{
  int count = 0;                                                                //Variable declaration
  for(int i=2; i<=number/2; i++)
  {
     if(number%i == 0)                                                          //Checking the num is prime or not
     {
       count=1;
       break;
     }
  }
  if(number == 1) count = 1;
  return count;                                                                 //Returning the count to main function
}