/*
Name : Anand S M
Date : 29-10-2023
Description : Program to find which day of the year
Sample execution :-)

Test Case 1:

Enter the value of 'n' : 9
Choose First Day :
1. Sunday
2. Monday
3. Tuesday
4. Wednesday
5. Thursday
6. Friday
7. Saturday
Enter the option to set the first day : 2
The day is Tuesday

Test Case 2:
Enter the value of 'n' : 9
Choose First Day :
1. Sunday
2. Monday
3. Tuesday
4. Wednesday
5. Thursday
6. Friday
7. Saturday
Enter the option to set the first day : 3
The day is Wednesday

Test Case 3: 
Enter the value of 'n' : 9

Choose First Day :

1. Sunday
2. Monday
3. Tuesday
4. Wednesday
5. Thursday
6. Friday
7. Saturday
Enter the option to set the first day : 8
Error: Invalid input, first day should be > 0 and <= 7

Test Case 4:

Enter the value of 'n' : 0
Error: Invalid Input, n value should be > 0 and <= 365
Test Case 5:
Enter the value of 'n' : 366
Error: Invalid Input, n value should be > 0 and <= 365
*/

//code

#include <stdio.h>

int main()
{
    int nth_day,start_day;                                                      //Declaring nth day adn start day to take as input
    printf("Enter the value of 'n' :");
    scanf("%d",&nth_day);
    if ( nth_day > 0 && nth_day <= 365)                                         //Checking nth day for the condition be > 0 and <=365
    {
        printf("Choose First Day :\n1.Sunday\n2.Monday\n3.Tuesday\n4.Wednesday\n5.Thursday\n6.Friday\n7.Saturday\n");   //Displaying the days list
        printf("Enter the option to set the first day :");
        scanf("%d",&start_day);                                                 //Taking start day as input
        
        if( start_day > 0 && start_day <= 7)                                    //Start day should be > 0 and <=7
        {
            int var,res_day=0;                                                  //Logic to find result and var to find the day
            res_day = nth_day+start_day-2;
            var = res_day % 7;
            switch(var)                                                         //Using switch case to print the result day
            {
                case 0:
                        printf("The day is Sunday");
                        break;
                case 1:
                        printf("The day is Monday");
                        break;
                case 2:
                        printf("The day is Tuesday");
                        break;
                case 3:
                        printf("The day is Wednesday");
                        break;
                case 4:
                        printf("The day is Thursday");
                        break;
                case 5:
                        printf("The day is Friday");
                        break;
                case 6:
                        printf("The day is Saturday");
                        break;
                default : ;
                        
            }
        }
        else
            printf("Error: Invalid input, first day should be > 0 and <= 7");       //Error message for invalid input for start day
        
        
    }
    
    
    else
    printf("Error: Invalid Input, n value should be > 0 and <= 365");           ////Error message for invalid input for nth day
    
    return 0;
}