/*
Name : Anand S M
Date : 10-11-2023
Description : Program to replace 'n' bits of given number
Sample Execution :-)

Test Case 1:

Enter the number: 10

Enter number of bits: 3

Enter the value: 12

Result = 12

Test Case 2:

Enter the number: 15

Enter number of bits: 2

Enter the value: 1

Result =  13
*/




//code

#include <stdio.h>

int replace_nbits(int, int, int);

int main()
{
    int num, n, val, res = 0;                                                   // Variable declaration
    
    printf("Enter num, n and val:");
    scanf("%d%d%d", &num, &n, &val);
    
    res = replace_nbits(num, n, val);                                           // Calling the function by passing the acctual arguments
    
    printf("Result = %d\n", res);                                               // Displaying the result
}

int replace_nbits(int num,int n, int val)                                       //Function definition            
{
    int res1,res2,res3=0;                                                       // Declaring the local variables
    
    res1 = ((1 << n)-1) & val;                                                  //Getting res1
    
    res2 = ~((1 << n)-1) & num;                                                 // Clearing the bit
    
    res3 = res1 | res2;                                                         // Merging the res1 and res2 with bitwise OR and passing the res3 to main()
    
    return res3;
}
 