/*
Name : Anand S M
Date : 12-11-2023
Description : Program to print 'n' bits from LSB of a number
Sample Execution : 

Test Case 1:

Enter the number: 10

Enter number of bits: 12

Binary form of 10: 0 0 0 0 0 0 0 0 1 0 1 0 

Test Case 2:

Enter the number: 15

Enter number of bits: 4

Binary form of 15: 1 1 1 1
*/

//code

#include <stdio.h>

int print_bits(int, int);

int main()
{
    int num, n;                                                                 // Variable declaration
    
    printf("Enter num, n :\n");
    scanf("%d%d", &num, &n);
    
    printf("Binary form of %d: ", num);
    print_bits(num, n);                                                         // Calling the function to print 'n' bits
 }
 
int print_bits(int num,int n)
{
    int res,i=0;
    for(i=n-1 ; i>=0 ; i--)                                                     // Checking and printing the bits using loop and ternary condition
    {
        res = num & (1 << i) ;
        res == 0 ? printf("0 ") : printf("1 ");
    }
    return res;
}