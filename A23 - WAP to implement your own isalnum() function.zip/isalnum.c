/*
Name : Anand S M
Date : 22-11-2023
Description : Program to implement own isalnum() function
Sample execution :-)

Test case 1 :
Enter the character: a
The character 'a' is an alnum character.

Test Case 2:
Enter the character: ?
The character '?' is not an alnum character.
*/

//code

#include <stdio.h>

int my_isalnum(char);                                                            // Function declaration

int main()
{
    char ch;                                                                    // Variable declaration
    int ret;
    
  //printf("Enter the character:");                                             // Read character ch
    scanf("%c", &ch);
    
    ret = my_isalnum(ch);                                                       // Function call with ch as actual argument
    
    ret == 0 ? printf("Entered character is not alphanumeric character") :                                                             // Printing the result based on ret
               printf("Entered character is alphanumeric character");
}

int my_isalnum(char ch)                                                         // Function definition for isalnum() function implementation
{
    if ( (ch >= 65 && ch <= 90) | (ch >= 97 && ch <= 122) | (ch >= 48 && ch <= 57) )    // Comparing ch with Ascii values and return 1 or 0 based on the result 
        return 1;
    else
        return 0;
}