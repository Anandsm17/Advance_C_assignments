/*
Name : Anand S M
Date : 28-10-2023
Description : Program to generate AP,GP and HP series

Sample execution :-)

Test Case 1:
Enter the First Number 'A': 2
Enter the Common Difference / Ratio 'R': 3
Enter the number of terms 'N': 5
AP = 2, 5, 8, 11, 14
GP = 2, 6, 18, 54, 162
HP = 0.500000, 0.200000, 0.125000, 0.090909, 0.071428

Test Case 2:
Enter the First Number 'A': 2
Enter the Common Difference / Ratio 'R': 3
Enter the number of terms 'N': -5
Invalid input
*/

#include <stdio.h>
#include<math.h>                                                    //importing math library for pow() function

int main()
{
    int a,r,n,ap,gp,hp,i;                                                       //Taking a,r,n as input
    printf("Enter the First Number 'A':");
    scanf("%d",&a);
    printf("Enter the Common Difference / Ratio 'R':");
    scanf("%d",&r);
    printf("Enter the number of terms 'N': ");
    scanf("%d",&n);
    
    if( n > 0)                                                                  //Checking the number is positive or not
    {
        //Arithmetic progression
        
        printf("AP = ");
        for(i=0;i<n;i++)
        {
            printf("%d,",a+i*r);                                                //Finding and displaying AP series
        }
        printf("\n");
        
        //Geometric progression
        
        printf("GP = ");
        for(i=0;i<n;i++)
        {
            printf("%d, ", (int) (a * pow(r,i)));                               //Fnding and displaying GP series
        }
        printf("\n");
        
        //Harmonic progression
        
        printf("HP = ");
		for ( i = 0; i < n; i++ ) 
		{
		    printf("%f, ", (double)1/(a+i*r));                                  // HP is Reciprocal of AP and using explicit typecasting for decimal points
		}
		printf("\n");
    }
    else
    printf("Invalid input");
    return 0;
}