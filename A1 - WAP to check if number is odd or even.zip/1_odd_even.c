/*
Name : Anand S M    
Date : 21-10-2023
Description : Program to check entered number should  be identified whether its a odd or a even number and mention its sign too
Sample execution :-)

Test case 1

Enter the value of 'n' : -2
-2 is negative even number

Test Case 2:

Enter the value of 'n' : 2
2 is positive even number

Test Case 3:

Enter the value of 'n' : 0
0 is neither odd nor even */


#include <stdio.h>

int main()
{
    
    int num;                                            //Taking num as input                        
    printf("Enter the number : ");
    scanf("%d",&num);
    printf("\n");
    if (num > 0)                                        //Checking whether the num is positive or not
    {
        if(num % 2 == 0)                                //Checking the num is odd or even
        printf("%d is positive even number",num);
        else
        printf("%d is positive odd number",num);
    }
    else if (num < 0)                                   //Checking whether the num is negative or not
    {
        if( num % 2 == 0)                               //Checking the num is odd or even
        printf("%d is negative even number",num);
        else
        printf("%d is negative odd number",num);
    }
    else 
        printf("%d is neither odd nor even",num);       
    return 0;
}