/*
Name : Anand S M
Date : 31-10-2023
Description : Program to print triangle pattern as shown below
Sample Output:
Test Case 1:
Enter the number: 4
1 2 3 4
5     6
7 8
9

Test Case 2:
Enter the number: 5
1 2 3 4 5
6       7
8    9
10 11
12
*/

//code

#include<stdio.h>

int main()

{
    int row,col,num,res=1;                                                      //Variables declration
    printf("Enter the number:");
    scanf("%d",&num);                                                           //Read num
    
    for(row=1 ; row <= num ; row++)
    {
        for(col=1; col <= num ; col++)
        {                         
    // using if  to get the numbers based on valuve and empty space considering

           if(row == 1 || col == 1 || col == num-row+1)             
           
   // value printing in rows and columns         
            {             
            
               printf("%d ",res++);
            
            }
  // to print the empty space 
       
        else if(col>num-row+1)
       
            {
                printf(" ");
            }
        
           else
            {
                printf("  ");  
               
            }
        }

       printf("\n");
        
              
    }   
         
return 0;

}