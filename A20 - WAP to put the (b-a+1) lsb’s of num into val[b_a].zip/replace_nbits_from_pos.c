/*
Name : Anand S M
Date : 15-11-2023
Description : Program to put the (b-a+1) lsb's of num into val[b:a]
Sample execution: -
Test Case 1:
user@emertxe] ./bit_ops
Enter the value of 'num' : 11
Enter the value of 'a' : 3
Enter the value of 'b' : 5
Enter the value of 'val': 174
Result : 158
*/

//code

#include <stdio.h>

int replace_nbits_from_pos(int, int, int, int);

int main()
{
    int num, a, b, val, res = 0;                                                // Variable declaration
    
    printf("Enter num, a, b, and val:");
    scanf("%d%d%d%d", &num, &a, &b, &val);                                      // Read num,a,b and val
    
    if (a <= b && b <= 31)                                                      // Validation
    {
        res = replace_nbits_from_pos(num, a, b-a+1, val);                       // Calling the function by passing arguments
        printf("Result = %d\n", res);
    }
    else
        printf("Invalidinput : Please pass the value a and b less than or equal to 31\n"); // a and b value above 31 to print the error message
    return 0;
}

int replace_nbits_from_pos(int num,int a,int b,int val)
{
    int res1,res2,res;                                                          // Local variables declaration
    res1= ((num & ((1 << a)-1)) << a);                                          // Clearing and getting the bits
    res2= (val & (~(((1 << a)-1) << a)));                                       
    res = res1 | res2;                                                          // Merging the res1 and res2 and returning the res
    return res;
}