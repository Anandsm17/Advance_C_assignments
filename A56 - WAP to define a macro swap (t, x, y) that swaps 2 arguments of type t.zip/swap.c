/*
Name : Anand S M
Date of submission : 16-05-2024
Description : Program to define a macro swap (t, x, y) that swaps 2 arguments of type t
Sample execution: -
Test Case 1:
user@emertxe] ./swap
1. Int
2. char
3. short
4. float
5. double
6. string
Enter you choice : 1

Enter the num1 : 10
Enter the num2 : 20
After Swapping :
num1 : 20
num2 : 10
*/

//code

#include <stdio.h>
#include <string.h>

// Macro to swap two values of type t
#define swap(t, x, y) { t temp = x; x = y; y = temp; }

void swapStrings(char *str1, char *str2) {
    char temp[100];
    strcpy(temp, str1);
    strcpy(str1, str2);
    strcpy(str2, temp);
}

int main() {
    int choice;
    printf("1. Int\n2. char\n3. short\n4. float\n5. double\n6. string\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch(choice) {
        case 1: { // Swap integers
            int num1, num2;
            printf("Enter the num1: ");
            scanf("%d", &num1);
            printf("Enter the num2: ");
            scanf("%d", &num2);

            printf("Before Swapping:\nnum1: %d\nnum2: %d\n", num1, num2);

            swap(int, num1, num2);

            printf("After Swapping:\nnum1: %d\nnum2: %d\n", num1, num2);
            break;
        }
        case 2: { // Swap characters
            char ch1, ch2;
            printf("Enter the ch1: ");
            scanf(" %c", &ch1);
            printf("Enter the ch2: ");
            scanf(" %c", &ch2);

            printf("Before Swapping:\nch1: %c\nch2: %c\n", ch1, ch2);

            swap(char, ch1, ch2);

            printf("After Swapping:\nch1: %c\nch2: %c\n", ch1, ch2);
            break;
        }
        case 3: { // Swap short integers
            short s1, s2;
            printf("Enter the s1: ");
            scanf("%hd", &s1);
            printf("Enter the s2: ");
            scanf("%hd", &s2);

            printf("Before Swapping:\ns1: %hd\ns2: %hd\n", s1, s2);

            swap(short, s1, s2);

            printf("After Swapping:\ns1: %hd\ns2: %hd\n", s1, s2);
            break;
        }
        case 4: { // Swap floats
            float f1, f2;
            printf("Enter the f1: ");
            scanf("%f", &f1);
            printf("Enter the f2: ");
            scanf("%f", &f2);

            printf("Before Swapping:\nf1: %f\nf2: %f\n", f1, f2);

            swap(float, f1, f2);

            printf("After Swapping:\nf1: %f\nf2: %f\n", f1, f2);
            break;
        }
        case 5: { // Swap doubles
            double d1, d2;
            printf("Enter the d1: ");
            scanf("%lf", &d1);
            printf("Enter the d2: ");
            scanf("%lf", &d2);

            printf("Before Swapping:\nd1: %lf\nd2: %lf\n", d1, d2);

            swap(double, d1, d2);

            printf("After Swapping:\nd1: %lf\nd2: %lf\n", d1, d2);
            break;
        }
        case 6: { // Swap strings (character arrays)
            char str1[100], str2[100];
            printf("Enter the str1: ");
            scanf("%s", str1);
            printf("Enter the str2: ");
            scanf("%s", str2);

            printf("Before Swapping:\nstr1: %s\nstr2: %s\n", str1, str2);

            swapStrings(str1, str2);

            printf("After Swapping:\nstr1: %s\nstr2: %s\n", str1, str2);
            break;
        }
        default:
            printf("Invalid choice!\n");
    }

    return 0;
}
