/*
Name : Anand S M
Date : 28-10-2023
Description : Program to check tif the given number is perfect number or not
Sample execution :-)

Test Case 1:

Enter a number: 6

Yes, entered number is perfect number

Test Case 2:
Enter a number: 10

No, entered number is not a perfect number

Test Case 3:
Enter a number: -1

Error : Invalid Input, Enter only positive number
*/

#include<stdio.h>

int main()
{
    int num,sum=0;                                                              //Declaration of num,sum and i 
    int i;
    printf("Enter the number: ");
    scanf("%d",&num);                                                           //Taking num as input  
    printf("\n");
    if ( num > 0)                                                               //Checking the num is positive
    {
        for (i=1 ; i<num ;i++)                                                      
        {
            if(num % i == 0 )                                                   //Checking for the divisiors
            {
                sum=sum+i;                                                      //sum of factors
            }
        }

        if(num == sum)                                                          //comparing the sum and num for result
            printf("Yes, entered number is perfect number");
        else
            printf("No, entered number is not a perfect number");
    }
    else
        printf("Error : Invalid Input, Enter only positive number");                                                //This message will be displayed for input given less than 1
    return 0;
}