/*
Name : Anand S M
Date of submission : 16-05-2024
Description : Read n & n person names of maxlen 20. Sort and print the names
Sample execution: -
Test Case 1:
user@emertxe] ./sort

Enter the size: 5

Enter the 5 names of length max 20 characters in each
[0] -> Delhi
[1] -> Agra
[2] -> Kolkata
[3] -> Bengaluru
[4] -> Chennai

The sorted names are:
Agra
Bengaluru
Chennai
Delhi
Kolkata
*/

//code

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to compare two strings for qsort
int compare(const void *a, const void *b) {
    return strcmp(*(const char **)a, *(const char **)b);
}

int main() {
    int N;
    printf("Enter the size: ");
    scanf("%d", &N);

    // Allocate memory for an array of N pointers to strings
    char **names = (char **)malloc(N * sizeof(char *));
    if (names == NULL) {
        printf("Memory allocation failed\n");
        return 1;
    }

    // Read N names from the user
    printf("Enter the %d names of length max 20 characters in each\n", N);
    for (int i = 0; i < N; i++) {
        names[i] = (char *)malloc(20 * sizeof(char)); // Allocate memory for each name
        if (names[i] == NULL) {
            printf("Memory allocation failed\n");
            return 1;
        }
        printf("[%d] -> ", i);
        scanf("%s", names[i]);
    }

    // Sort the names using qsort
    qsort(names, N, sizeof(char *), compare);

    // Print the sorted names
    printf("\nThe sorted names are:\n");
    for (int i = 0; i < N; i++) {
        printf("%s\n", names[i]);
    }

    // Free allocated memory
    for (int i = 0; i < N; i++) {
        free(names[i]);
    }
    free(names);

    return 0;
}
